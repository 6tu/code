<?php
/**
 * Proxy interface.
 * @package repose
 */

/**
 * Proxy interface.
 * @package repose
 */
interface repose_IProxy {

}
?>
