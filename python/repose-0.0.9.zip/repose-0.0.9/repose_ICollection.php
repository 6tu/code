<?php
/**
 * Collection interface
 * @package repose
 */

require_once('repose_Session.php');
require_once('repose_InstanceCache.php');
require_once('repose_IProxy.php');

/**
 * Collection interface
 * @package repose
 */
interface repose_ICollection {
}
?>
