<?php
class terms extends Controller {}