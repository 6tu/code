<?php
class privacy extends Controller {}
