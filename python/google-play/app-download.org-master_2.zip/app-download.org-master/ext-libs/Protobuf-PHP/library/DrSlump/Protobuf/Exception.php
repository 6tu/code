<?php

namespace DrSlump\Protobuf;

class Exception extends \Exception
{

}