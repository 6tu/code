#!/bin/bash
java -jar webpage-tunnel.jar
