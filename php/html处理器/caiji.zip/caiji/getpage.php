<?php

error_reporting(E_ALL);

set_time_limit(0);
date_default_timezone_set("America/Los_Angeles"); # 洛杉矶时间

$t = date('ymdH', time());
$log_dir = './log/';
if(!is_dir($log_dir)) mkdir($log_dir, 0777);

$cookie_dir = './cookie/';
if(!is_dir($cookie_dir)) mkdir($cookie_dir, 0777);
$cookie_file = $cookie_dir . time() . '.cookie';
setcookie("PHPSESSID", "vc0heoa6lfsi3gger54pkns152");

header("Content-type: text/html; charset=utf-8");


$url = 'https://shideyun.com/test/23-6_16K.mp3';
$url = 'https://shideyun.com/test/n2797182.html?hgjhgj';
$res_array = getResponse($url, $data = [], $cookie_file = './cookie/.cookie');

//print_r($res_array);

# 获取文件名
function filename($url, $mime){
    # 如果文件没有后缀，则根据 mime_type 追加
    $array_url = parse_url(trim($url));
    $fn = substr(@$array_url['path'], strrpos(@$array_url['path'], "/") + 1);
    return $fn;
}

# 转为 utf8
function status2utf8($res_array){
    if($res_array['status'] != 200 ){
        echo "状态码为 " . $res_array['status'] . " , 错误原因可能是： ";
        $status = substr($res_array['status'] , 0 , 1);
        if($status == 1 ) echo '服务器正在处理请求';
        if($status == 2 ) echo '请求正常处理完毕';
        if($status == 3 ) echo '请求重定向';
        if($status == 4 ) echo '客户端错误';
        if($status == 5 ) echo '服务器错误';
        exit;
    }

    # 转为 UTF-8 
    if($res_array['charset'] !== 'utf-8' and strpos($res_array['mime_type'], 'text') !== false){
        // if(extension_loaded('mbstring')) $res_array['body'] = mb_convert_encoding    ($res_array['body'], 'UTF-8', $res_array['charset']);
        // elseif(extension_loaded('iconv')) $res_array['body'] = iconv($res_array['charset'], 'UTF-8    //IGNORE//TRANSLIT', $res_array['body']);
        $res_array['body'] = @iconv($res_array['charset'], 'UTF-8//IGNORE//TRANSLIT',     $res_array['body']);
        return $res_array['body'];
    }
}

# CSS 选择器
# $div 的固定类型
function getarticle($html, $div){
    # 删除 JS
    $preg = "/<script[\s\S]*?<\/script>/i";
    $html = preg_replace($preg, "", $html, -1);
    $html = preg_replace('#<\s*script[^>]*?>.*?<\s*/\s*script\s*>#si', '', $html);
    $html = preg_replace("#(\bon[a-z]+)\s*=\s*(?:\"([^\"]*)\"?|'([^']*)'?|([^'\"\s>]*))?#i", '',     $html);
    $html = preg_replace('#<noscript>(.*?)</noscript>#si', "$1", $html);

    require('./lib/phpQuery/phpQuery.php');
    // $html = phpQuery::newDocumentFile($url);
    $html = phpQuery::newDocument($html);
    $title = pq("title")->text();	// 获取网页标题
    //$article = pq("div#article-content")->html();	// 获取id为header的div的html内容
    $article = pq($div)->html();

    $head = '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8">';
    $head .= '<title>' . $title . '</title></head><body>';
    //$head = str_replace(">", ">\r\n", $head);
    # 多个空格转为一个空格
    $article = preg_replace ("/\s(?=\s)/", "\\1", $article);
    $article = preg_replace('/\s{2,}|\n/i', '', $article);


    $article = strip_space_enter($article, '<span><a>', $n = 10);
    $article = str_replace('</a>', "</a><br>\r\n", $article);
    $article = str_replace('<a href="', '<a href="?url=https:',  $article);
    $article = str_replace(array('</span></a>','<span'), array('</span>','</a><span'), $article);
    
    $html = $head . "<h4> $title </h4>\r\n" . $article;
    return beautify_html($html);
}

# HTML 格式化
function beautify_html($html){
    $tidy_config = array(
        'clean' => false,
        'indent' => true,
        'indent-spaces' => 4,
        'output-xhtml' => false,
        'show-body-only' => false,
        'wrap' => 0
        );
    if(function_exists('tidy_parse_string')){ 
        $tidy = tidy_parse_string($html, $tidy_config, 'utf8');
        $tidy -> cleanRepair();
        return $tidy;
    }else{
        require_once('./lib/beautify-html.php');
        // Set the beautify options
        $beautify = true;
        if($shouldBeautify = true) {
        	$beautify = new Beautify_Html(array(
        	  'indent_inner_html' => false,
        	  'indent_char' => " ",
        	  'indent_size' => 4,
        	  'wrap_line_length' => 32786,
        	  'unformatted' => ['code', 'pre'],
        	  'preserve_newlines' => false,
        	  'max_preserve_newlines' => 32786,
        	  'indent_scripts'	=> 'normal' // keep|separate|normal
        	));
        }
        //$beautify = new Beautify_Html;
        $html = $beautify->beautify($html);
        return $html;
    }
}

# 删除空格和回车
function strip_space_enter($html, $tags, $n){
	$html = strip_tags($html, $tags);
	$html = trim($html);
    for($i = 0; $i < $n; $i++){
        $html = str_replace(array(" \r\n", " \n", ' <', '> '), array("\r\n", "\n", '<', '>'), $html);
    }
    $html = str_replace(array("\r\n", "\n", "\r", '&nbsp;', "\t",), array(''), $html);
	return $html;
}

# 使用CURL获取网页内容，报头，状态码，mime类型和编码 charset
# CURLOPT_CONNECTTIMEOUT 请求连接超时
# CURLOPT_TIMEOUT 响应数据传输时允许时间
# 支持GET和POST,返回值网页内容，报头，状态码，mime类型和编码 charset
function getResponse($url, $data = [], $cookie_file = ''){

    $url_array = parse_url($url);
    $host = $url_array['scheme'] . '://' . $url_array['host'];
    if(!empty($_SERVER['HTTP_REFERER'])) $refer = $_SERVER['HTTP_REFERER'];
    else $refer = $host . '/';
    if(!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) $lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
    else $lang = 'zh-CN,zh;q=0.9';
    if(!empty($_SERVER['HTTP_USER_AGENT'])) $agent = $_SERVER['HTTP_USER_AGENT'];
    else $agent = 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.67 Safari/537.36';
    // $agent = 'Wget/1.18 (mingw32)'; # 'Wget/1.17.1 (linux-gnu)';
    // echo "<pre>\r\n" . $agent . "\r\n" . $refer . "\r\n" . $lang . "\r\n\r\n";
	
    if(empty($cookie_file)){
        $cookie_file = '.cookie';
    }
	
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_USERAGENT, $agent);
    curl_setopt($ch, CURLOPT_REFERER, $refer);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Accept-Language: " . $lang));
    if(!empty($data)){
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);   # 302 重定向
    curl_setopt($ch, CURLOPT_AUTOREFERER, true);      # 301 重定向

    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie_file);  # 取cookie的参数是
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie_file); # 发送cookie
	
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 8);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($ch);
    curl_close($ch);
	
	# try{}catch{}语句
    // try{
    //     $handles = curl_exec($ch);
    //     curl_close($ch);
    //     return $handles;
    // }
    // catch(Exception $e){
    //     echo 'Caught exception:', $e -> getMessage(), "\n";
    // }
    // unlink($cookie_file);

    $res_array = explode("\r\n\r\n", $result, 2);
    $headers = explode("\r\n", $res_array[0]);
    $status = explode(' ', $headers[0]);
    # 如果$headers为空，则连接超时
    if(empty($res_array[0])) die('<br><br><center><b>连接超时</b></center>');
    # 如果$headers状态码为404，则自定义输出页面。
    if($status[1] == '404') die("<pre><b>找不到，The requested URL was not found on this server.</b>\r\n\r\n$res_array[0]</pre>\r\n\r\n");
    # 如果$headers第一行没有200，则连接异常。
    # if($status[1] !== '200') die("<pre><b>连接异常，状态码： $status[1]</b>\r\n\r\n$res_array[0]</pre>\r\n\r\n");\

    if($status[1] !== '200'){
        $body_array = explode("\r\n\r\n", $res_array[1], 2);
        $header_all = $res_array[0] . "\r\n\r\n" . $body_array[0];
        $res_array[0] = $body_array[0];
        $body = $body_array[1];
    }else{
        $header_all = $res_array[0];
        $body = $res_array[1];
    }

    $headers = explode("\r\n", $res_array[0]);
    $status = explode(' ', $headers[0]);
    
    $headers[0] = str_replace('HTTP/1.1', 'HTTP/1.1:', $headers[0]);
    foreach($headers as $header){
        if(stripos(strtolower($header), 'content-type:') !== FALSE){
            $headerParts = explode(' ', $header);
            $mime_type = trim(strtolower($headerParts[1]));
            //if(!empty($headerParts[2])){
            //    $charset_array = explode('=', $headerParts[2]);
            //    $charset = trim(strtolower($charset_array[1]));
            //}
        }
        if(stripos(strtolower($header), 'charset') !== FALSE){
            $charset_array = explode('charset=', $header);
            $charset = trim(strtolower($charset_array[1]));
        }else{
            $charset = preg_match("/<meta.+?charset=[^\w]?([-\w]+)/i", $res_array[1], $temp) ? strtolower($temp[1]):"";
        }
    }
    if(empty($charset)) $charset = 'utf-8';
    if(strstr($charset, ';')){
        $charset_array = '';
        $charset_array = explode(';', $charset);
        $charset = trim($charset_array[0]);
        //$charset = str_replace(';', '', $charset);
    }
    if(strstr($mime_type, 'text/html') and $charset !== 'utf-8'){
        $body = mb_convert_encoding ($body, 'utf-8', $charset);
    }
    # $body = preg_replace('/(?s)<meta http-equiv="Expires"[^>]*>/i', '', $body);    
    
    # echo "<pre>\r\n$header_all\r\n\r\n" . "$status[1]\r\n$mime_type\r\n$charset\r\n\r\n";
    # header($res_array[0]);

    $res_array = array();
    $res_array['header']    = $header_all;
    $res_array['status']    = $status[1];
    $res_array['mime_type'] = $mime_type;
    $res_array['charset']   = $charset;
    $res_array['body']      = $body;
    return $res_array;
}

