<?php

require_once __DIR__ . '/php-sdk-7.2.6/autoload.php';

use Qiniu\Auth;                   // 引入鉴权类
use Qiniu\Storage\UploadManager;  // 引入上传类

// 需要填写你的 Access Key 和 Secret Key
// 使用 test-env.sh 给系统增加 QINIU_ACCESS_KEY 等变量，然后使用getenv() 调用这些变量，但这对WINDOWS并不适用
$accessKey = 'KzBWtGa-Qsxd2zA_SbYkcxi9Evw0fRNgQY5ax9T6';
$secretKey = 'F8JQ4riqVfQmgCyDWya9Oi5TYBtNpOKBToYUxEyh';
$bucket = 'yisuo';
$auth = new Auth($accessKey, $secretKey);  // 构建鉴权对象

# $filePath = './p7m_2018-8-23-t.zip.b64.zip'; // 要上传文件的本地路径
# $key = "mhdata/p7m_2018-8-23-t.zip.b64.zip"; // 上传到七牛后保存的文件名
# $key = time().'my-php-logo.png';             // 避免重复

# $token = $auth->uploadToken($bucket);        // 生成上传 Token
$token = $auth->uploadToken($bucket, $key, 3600, array('insertOnly' => 0));  // insertOnly' 覆盖性上传

// 初始化 UploadManager 对象并进行文件的上传。
$uploadMgr = new UploadManager();

// 调用 UploadManager 的 putFile 方法进行文件的上传。
list($ret, $err) = $uploadMgr->putFile($token, $key, $filePath);













