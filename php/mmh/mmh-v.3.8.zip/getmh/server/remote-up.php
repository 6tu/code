<?php

set_time_limit(0);
$up_dir = 'mhdata';
if (is_dir($up_dir) == false) {
    mkdir($up_dir, 0777);
}

form_html();
//print_r($_REQUEST);
$allowedExtensions = array("txt", "zip", "7z", "rar");
echo '允许上传的文件类型    <b>' . implode(",", $allowedExtensions) . "</b>\r\n<br><br>";

if (!empty($_FILES['file'])) {
    $file = $_FILES['file'];
    if ($file['error'] == UPLOAD_ERR_OK) {
        if (in_array(end(explode(".", $file['name'])), $allowedExtensions)) {
            $name = $file['name'];
            $size = round($file['size'] / 1024, 2);
            move_uploaded_file($file['tmp_name'], "{$up_dir}/{$name}");
            @chmod("{$up_dir}/{$name}", 0755);
            echo $name . " (" . $size . "KB) 已上载成功！ \r\n<br><br>";
        } else {
            echo $file['name'] ." 该文件不允许上传 <br><br>\r\n";
        }
    } else {
        die("不能上传 <br><br>\r\n");
    }
}
echo "\r\n</center><table border='0' align='center'>\r\n";
echo view_dir($up_dir). "</table>\r\n</body>\r\n</html>";


function view_dir($dir){
    $dp = opendir($dir);                      # 打开目录句柄
                                              # echo "<br>".$dir."<br><br>";
    while ($file = readdir($dp)) {            # 遍历目录
        if ($file != '.' && $file != '..') {  # 如果文件不是当前目录及父目录
            $path = $dir . "/" . $file;       # 获取路径
            if (is_dir($path)) {              # 如果当前文件为目录
                view_dir($path);              # 递归调用
            } else {                          # 如果不是目录
                echo '<tr><td><a href="' . $path . '">' . $path . "</a><br></td></tr>\r\n";  # 输出文件名
            }
        }
    }
    closedir($dp);
}

function form_html(){
    $html = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\r\n<html>\r\n<head>\r\n<title>File upload</title>\r\n";
    $html .= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n</head>\r\n<body>\r\n<br><center>\r\n";
    $html .= '<form name="form" method="POST" action="' .$_SERVER['SCRIPT_NAME']. '" enctype="multipart/form-data">' . "\r\n";
    $html .= '  <input type="file" name="file" value="浏览">' . "\r\n" . '  <input type="submit" name="btnUpload" value="上传">';
    $html .= "\r\n</form>\r\n";
    echo $html;
}

/*
<?php
header('content-type:text/html;charset=utf8');

$file = dirname(__FILE__).'/WebShellKill_V1.4.1.zip';
$data['file'] = new CurlFile($file);
$url = "https://ipip.ysuo.org/mmh/index.php";

$ch = curl_init();
curl_setopt($ch,CURLOPT_URL, $url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POST,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
$result = curl_exec($ch);
curl_close($ch);
$result = explode('<br><br>', $result);

echo $result[1];
*/

