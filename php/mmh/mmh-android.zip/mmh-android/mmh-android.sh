#!/system/bin/sh

#判断CPU是否是arm的
cpu=`getprop ro.product.cpu.abi`
if [[ $cpu =~ "arm" ]] ;
then
        echo $cpu
else
        echo " This shell applies only to arm "
        exit
fi

#检测网络的联通性
pingres=`ping -c 1 119.29.23.116 | sed -n '/64 bytes from/p'`
if [ -z "$pingres" ]
then
        echo " network error 互联网(外网)连接异常" 
        exit 1
fi

mmhpath=/sdcard/download/mmh
databin=/data/local/bin
#复制执行文件到指定目录，并设置属性0755

su
mount -o remount /data
mount -o remount /system
#cd $mmhpath/bin/
#cp unzip openssl wget base64 /system/bin/
#cd /system/bin/
#chmod 0755 unzip openssl wget base64

test -d $databin         || mkdir -p $databin
test -f $databin/unzip   || cp -rf $mmhpath/bin/unzip   $databin/
test -f $databin/openssl || cp -rf $mmhpath/bin/openssl $databin/
test -f $databin/wget    || cp -rf $mmhpath/bin/wget    $databin/
test -f $databin/base64  || cp -rf $mmhpath/bin/base64  $databin/
chmod 0755 $databin/unzip
chmod 0755 $databin/openssl
chmod 0755 $databin/wget
chmod 0755 $databin/base64
chmod -R $databin

#从网络中获取日期，而不是更改本地的日期
#月份前面有 0，echo `date +%Y%m%d`
xdate=`date +'%Y-%-m-%-d'`

echo " 一般在北京时间14:00左右更新内容"
read -t 10 -e -p " 请输入文件的发布日期，默认为:" -i $xdate  xdate
read -t 5  -e -p " 是否下载 $xdate 的文件？     " -i "Yes" REPLY
if [[ ! $REPLY =~ "Yes" ]] ;then
	echo " 已取消下载文件 "
    exit 1
fi

#设置文件名
fn=$xdate-t.zip
b64fn=p7m_$fn.b64
emlfn=$b64fn.eml
zipfn=$b64fn.zip

$databin/wget -o $mmhpath/mh.log http://ysuo.org/mmh/getmh.php?name=$fn

clear
echo
echo  远端文件更新完毕，2 秒钟后跳转到下载链接
echo
ping -c 2 127.0.0.1 >nul

cd $mmhpath
$databin/wget http://oold3s5tj.bkt.clouddn.com/mhdata/$zipfn
ping -c 1 127.0.0.1 >nul
$databin/unzip -o -d $mmhpath/mhdata $zipfn
$databin/openssl smime  -decrypt -in $mmhpath/mhdata/$emlfn -inkey $mmhpath/cert/mh.key  -out $mmhpath/mhdata/$b64fn
$databin/base64 -d $mmhpath/mhdata/$b64fn $mmhpath/mhdata/$fn
$databin/unzip unzip -o -d $mmhpath/mhdata $mmhpath/mhdata/$fn

rm -rf $mmhpath/*.php*
#rm -rf $mmhpath/mh.log
rm -rf $mmhpath/$zipfn
rm -rf $mmhpath/mhdata/$b64fn
rm -rf $mmhpath/mhdata/$emlfn
#rm -rf $mmhpath/mhdata/$fn

#cd $mmhpath/mhdata/$xdate-t
#adb shell am start -n {包(package)名}/{包(package)名}.{活动(activity)名称}
#{包(package)名}.{活动(activity)名称}可以从AndroidManifest.xml的文件中得到
am start -n com.android.chrome/com.google.android.apps.chrome.Main $mmhpath/mhdata/$xdate-t/$xdate-t.html



