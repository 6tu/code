#!/system/bin/sh

#判断CPU是否是arm的
arm=arm
cpu=`getprop ro.product.cpu.abi`
if [[ $cpu == *$arm* ]];then
    echo $cpu
else
    echo " This shell applies only to arm "
    exit
fi

#检测网络的联通性
pingres=`ping -c 1 119.29.23.116 | sed -n '/64 bytes from/p'`
if [[ -z $pingres ]];
then
    echo 'network error'
    exit
fi
clear

mmhpath=/sdcard/mmh
mmhdata=$mmhpath/mhdata
databin=/data/local/bin
#复制执行文件到指定目录，并设置属性0755

#su
#mount -o remount /data
#mount -o remount /system
#cd $mmhpath/bin/
#cp unzip openssl wget base64 /system/bin/
#cd /system/bin/
#chmod 0755 unzip openssl wget base64

test -d $databin         || mkdir -p $databin
test -f $databin/unzip   || cp -rf $mmhpath/bin/unzip   $databin/
test -f $databin/openssl || cp -rf $mmhpath/bin/openssl $databin/
test -f $databin/wget    || cp -rf $mmhpath/bin/wget    $databin/
test -f $databin/base64  || cp -rf $mmhpath/bin/base64  $databin/
chmod 0755 $databin/unzip
chmod 0755 $databin/openssl
chmod 0755 $databin/wget
chmod 0755 $databin/base64
chmod -R 0755 $databin

#月份前面有 0, `date +%Y%m%d`
#月份前面不带 0, `date +'%Y-%-m-%-d'`
#从网络中获取日期，而不是更改本地的日期
echo
echo " 一般在北京时间14:00左右更新内容"
xdate=`wget -qO- http://ysuo.org/mmh/date.php`
read -t 10 -p " 请输入文件的发布日期，默认为:" -i $xdate  xdate
read -t 5  -p " 是否下载 $xdate 的文件？     " -i "Yes" REPLY

if [ $REPLY != "Yes" ];then
	echo " 已取消下载文件 "
    exit 1
fi

#设置文件名
fn=$xdate-t.zip
b64fn=p7m_$fn.b64
emlfn=$b64fn.eml
zipfn=$b64fn.zip

cd $mmhpath
test -d $mmhdata/$xdate-t || mkdir -p $mmhdata/$xdate-t
$databin/wget -O mmh.html http://ysuo.org/mmh/getmh.php?name=$fn

#clear
ping -c 2 127.0.0.1 > $mmhpath/ping.log
echo
echo  远端文件更新完毕，2 秒钟后跳转到下载链接
echo
$databin/wget -q -P $mmhpath/ http://oold3s5tj.bkt.clouddn.com/mhdata/$zipfn
ping -c 1 127.0.0.1 > $mmhpath/ping.log
$databin/unzip -o -d $mmhdata/ $zipfn
$databin/openssl smime -decrypt -in $mmhdata/$emlfn -inkey $mmhpath/cert/mh.key -out $mmhdata/$b64fn
$databin/base64 -d $mmhdata/$b64fn >  $mmhdata/$fn
$databin/unzip -o -d $mmhdata/$xdate-t $mmhdata/$fn

rm -rf $mmhpath/mmh.html
rm -rf $mmhpath/ping.log
rm -rf $mmhpath/$zipfn
rm -rf $mmhdata/$b64fn
rm -rf $mmhdata/$emlfn
#rm -rf $mmhdata/$fn

#adb shell am start -n {包(package)名}/{包(package)名}.{活动(activity)名称} file:/// 或者 http://
#{包(package)名}.{活动(activity)名称}可以从AndroidManifest.xml的文件中得到
am start -n com.android.chrome/com.google.android.apps.chrome.Main file:///$mmhdata/$xdate-t/$xdate-t.html

