<?php
require_once __DIR__ . '/php-sdk-7.2.6/autoload.php';
use Qiniu\Auth;                               # 引入鉴权类
use Qiniu\Storage\UploadManager;              # 引入上传类
$auth = new Auth($accessKey, $secretKey);     #构建鉴权对象
$token = $auth -> uploadToken($bucket, $key, 3600, array('insertOnly' => 0)); #生成上传Token,insertOnly'覆盖性上传
$uploadMgr = new UploadManager();                                             #初始化UploadManager对象并进行文件的上传。
list($ret, $err) = $uploadMgr -> putFile($token, $key, $filePath);            #调用UploadManager的putFile方法进行文件的上传
