<?php
//echo date("Y-n-j  H:i:s", time()) . "<br>\r\n";
//date_default_timezone_set('Asia/Shanghai');        #北京时间
//date_default_timezone_set ('America/New_York');    #美东时间
//date_default_timezone_set ("America/Los_Angeles"); # 美西时间
//date_default_timezone_set ("America/Chicago");
//date_default_timezone_set ("America/Phoenix");
//date_default_timezone_set ("America/Anchorage");
//date_default_timezone_set ("America/Adak");
//date_default_timezone_set ("Pacific/Honolulu");
//date_default_timezone_set ("America/Denver");
date_default_timezone_set ("Etc/GMT+6");             #比林威治标准时间慢6小时
echo date("Y-n-j", time());