<?php
# 语法注释用 // ,说明注释用 #
# http://blog.laobubu.net/442
# 在设置-->互操作存储访问密钥中生成 $accesskey和 $secret

set_time_limit(0);
error_reporting(1);
date_default_timezone_set ('America/New_York');
include('Storage.php');

$gcsurl = 'http://gcs.popcn.net';
$accesskey = 'GOOGMZIKG7TSBC3RPHTUOGTP'; #访问密钥
$secret = 'S9oqy41aSuZ4aNSysiSg2Brc4dwGFcCrT8OVBYod'; #密匙
$b = new Tws_Service_Google_Storage($accesskey, $secret);

# 获取桶名字列表
$lb = $b -> getBuckets();
foreach($lb as $lb_name => $lb_detail){
    // echo $lb_name . "\r\n\r\n";
}
$bucket = $lb_name;

# 文件名设置
$remotedir = 'mhdata';
$localdir = dirname(__FILE__) . '/';
$fn = 'app.zip';
// $fn = 'index.html';
$localfn = $localdir . $fn;
$remotefn = $bucket . '/' . $remotedir . '/' . $fn;

// echo "<pre>\r\n\r\n";
// $b -> putFile($localfn, $remotefn, array('acl' => Tws_Service_Google_Storage :: ACL_PUBLIC_READ));
/**
 * # 多文件上传
 * $cusdir = dirname($localdir) . '/mhdata';
 * $filenames = get_filenamesbydir($cusdir);
 * $fn = '';
 * foreach ($filenames as $value){
 *     $ext = pathinfo($value, PATHINFO_EXTENSION);
 *     if(strstr($ext, 'zip')){
 *         // $fn .= $value. PHP_EOL;
 *         $localfn = $value;
 *         $fn = str_replace($cusdir, '', $value);
 *         $remotefn = $remotedir . $fn;
 *         
 *         $b -> putFile($localfn, $remotefn, array('acl' => Tws_Service_Google_Storage :: ACL_PUBLIC_READ));
 *     }
 * }
 */

# 获取桶内物件列表
$lf = $b -> getObjectsByBucket($bucket);
$html = '';
foreach($lf as $lf_name => $lf_detail){
    // print_r($lf_detail); //. ' ' . $lf_detail['LastModified']
    if(strstr($lf_name, $remotedir) and !strstr($lf_name, 'index.html')){
        $path_array = pathinfo($lf_name);
        $html .= '        <tr>' . "\r\n";
        $html .= '            <td valign="top"></td>' . "\r\n";
        $html .= '            <td><a href="' . $gcsurl . '/' . $lf_name . '">' . $path_array['basename'] . '</a></td>' . "\r\n";
        $html .= '            <td align="right">' . $lf_detail['LastModified'] . '</td>' . "\r\n";
        $html .= '            <td align="right">' . bytesize($lf_detail['Size']) . '</td>' . "\r\n";
        $html .= '        </tr>' . "\r\n";
    }
}

# 更新 index.html
$url = $gcsurl . '/' . $remotedir;
$index_page = indexdir($url , $html);
echo $index_page;
file_put_contents($remotedir . '.html', $index_page);
$localfn = $localdir . $remotedir . '.html';
$remotefn = $bucket . '/' . $remotedir . '/index.html';
$b -> putFile($localfn, $remotefn, array('acl' => Tws_Service_Google_Storage :: ACL_PUBLIC_READ));

# 删除文件
// $delfn = $b -> removeObject($bucket.'/mhdata/glibc.zip');




# =============== 函数区，无需修改 =============== #
# 单位转换和字符长度补齐
function bytesize($num){
    $bt = pow(1024, 1);
    $kb = pow(1024, 2);
    $mb = pow(1024, 3);
    $gb = pow(1024, 4);
    if(!is_numeric($num)) $size = '值不是数字';
    if($num < 0) $size = '值不能小于 0 ';
    if($num >= 0 and $num < $bt) $size = $num . ' B';
    if($num >= $bt and $num < $kb) $size = floor(($num / $bt) * 100) / 100 . ' KB';
    if($num >= $kb and $num < $mb) $size = floor(($num / $kb) * 100) / 100 . ' MB';
    if($num >= $mb and $num < $gb) $size = floor(($num / $mb) * 100) / 100 . ' GB';
    if($num >= $gb) $size = floor(($num / $gb) * 100) / 100 . ' TB';
    return $size;
}

function bytecomplement($str){
    $bv = 50;
    $length = strlen($str);
    if($length < $bv){
        $dv = $bv - $length;
        $space = '';
        for($i = 0; $i < $dv; $i++){
            $space .= ' ';
		}
        }else{
            $space = '  ';
        }
    return $space;
}

# 获取目录下所有文件，包括子目录
function get_allfiles($path, &$files){
    if(is_dir($path)){
        $dp = dir($path);
        while ($file = $dp -> read()){
            if($file !== "." && $file !== ".."){
                get_allfiles($path . "/" . $file, $files);
            }
        }
        $dp -> close();
    }
    if(is_file($path)){
        $files[] = $path;
    }
}

function get_filenamesbydir($dir){
    $files = array();
    get_allfiles($dir, $files);
    return $files;
}

# 文件索引
function indexdir($url , $str){
    $url_array = (parse_url($url));
    $path_array = pathinfo($url_array['path']);
    $host = $url_array['scheme'] . '://' . $url_array['host'];
    $baseurl = $host . $path_array['dirname'];
    $pardir = $host . dirname($path_array['dirname']);
    // echo $baseurl;
    // echo $host;
    // print_r($url_array);
    // print_r($path_array);
    // $path_array['dirname'] => /mhdata $path_array['basename']
    $html = "\r\n";
    $html .= '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">' . "\r\n";
    $html .= '<html>' . "\r\n";
    $html .= '<head>' . "\r\n";
    $html .= '    <title>Index of ' . $baseurl . '</title>' . "\r\n";
    
    $html .= '</head>' . "\r\n";
    $html .= '<body>' . "\r\n";
    $html .= '    <h1>Index of ' . $baseurl . '</h1>' . "\r\n";
    
    $html .= '    <table>' . "\r\n";
    $html .= '        <tr>' . "\r\n";
    $html .= '            <th valign="top"></th>' . "\r\n";
    $html .= '            <th><font color="blue">Name</a></th>' . "\r\n";
    $html .= '            <th><font color="blue">Last modified</a></th>' . "\r\n";
    $html .= '            <th><font color="blue">Size</a></th>' . "\r\n";
    $html .= '        </tr>' . "\r\n";
    $html .= '        <tr>' . "\r\n";
    $html .= '            <th colspan="5"><hr></th>' . "\r\n";
    $html .= '        </tr>' . "\r\n";
    $html .= '        <tr>' . "\r\n";
    $html .= '            <td valign="top"></td>' . "\r\n";
    $html .= '            <td><a href="' . $pardir . '">Parent Directory</a></td>' . "\r\n";
    $html .= '            <td>&nbsp;</td>' . "\r\n";
    $html .= '            <td align="right">-</td>' . "\r\n";
    $html .= '        </tr>' . "\r\n";
    
    $html .= $str;
    // $html .= '        <tr>' ."\r\n";
    // $html .= '            <td valign="top"></td>' ."\r\n";
    // $html .= '            <td><a href="'.$url.'">'.$path_array['basename'].'</a></td>' ."\r\n";
    // $html .= '            <td align="right">2018-07-15 02:26</td>' ."\r\n";
    // $html .= '            <td align="right">5.7M</td>' ."\r\n";
    // $html .= '        </tr>' ."\r\n";
    $html .= '        <tr>' . "\r\n";
    $html .= '            <th colspan="5"><hr></th>' . "\r\n";
    $html .= '        </tr>' . "\r\n";
    $html .= '    </table>' . "\r\n";
    $html .= '</body>' . "\r\n";
    $html .= '</html>' . "\r\n";
    return ($html);
}

